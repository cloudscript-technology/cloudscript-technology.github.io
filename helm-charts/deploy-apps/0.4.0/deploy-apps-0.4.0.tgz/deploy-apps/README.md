# deploy-apps

Helm chart flexível para deploy de múltiplas aplicações (Deployment, StatefulSet, CronJob, Job) com suporte a External Secrets Operator e KEDA.

## Características

- **Multi-aplicação**: Deploy múltiplas aplicações em um único chart
- **Workload Types**: Suporte para Deployment, StatefulSet, CronJob e Job
- **External Secrets**: Integração com External Secrets Operator para gerenciamento seguro de secrets
- **Native Secrets**: Suporte também para secrets nativos do Kubernetes
- **RBAC Flexível**: ServiceAccount e RBAC global ou per-app
- **Probes**: Configuração completa de liveness, readiness e startup probes
- **Networking**: Service, Ingress e Gateway API (Envoy) configuráveis por aplicação
- **Persistence**: Suporte a PersistentVolumes, PersistentVolumeClaims e volumeClaimTemplates
- **Autoscaling**: HorizontalPodAutoscaler para Deployments e StatefulSets
- **KEDA**: Autoscaling event-driven com suporte a SQS, Redis, Kafka, RabbitMQ, Prometheus e mais
- **PodDisruptionBudget**: PDB nativo por aplicação (Deployment/StatefulSet), desabilitado por padrão

## Pré-requisitos

- Kubernetes >= 1.27
- Helm 3.x
- External Secrets Operator (opcional, apenas se usar external secrets)
- KEDA (opcional, apenas se usar kedaScaling)

## Instalação

### Adicionar o repositório Helm

```bash
helm repo add cloudscript https://charts.cloudscript.com.br
helm repo update
```

### Instalar o chart

```bash
helm install my-apps cloudscript/deploy-apps -f values.yaml
```

### Instalar de um arquivo local

```bash
helm install my-apps ./deploy-apps -f values.yaml
```

## Estrutura de Configuração

O chart usa uma estrutura baseada em array para definir múltiplas aplicações:

```yaml
apps:
  - name: app-name
    enabled: true
    type: deployment  # deployment, statefulset, cronjob, job
    # ... configurações específicas da aplicação
```

## Exemplos

### Exemplo 1: Deployment Simples com Ingress

```yaml
apps:
  - name: web-app
    enabled: true
    type: deployment
    replicaCount: 2

    image:
      repository: nginx
      tag: "1.21"
      pullPolicy: IfNotPresent

    ports:
      - name: http
        containerPort: 80
        protocol: TCP

    service:
      enabled: true
      type: ClusterIP
      ports:
        - name: http
          port: 80
          targetPort: http

    ingress:
      enabled: true
      className: nginx
      annotations:
        cert-manager.io/cluster-issuer: letsencrypt-prod
      hosts:
        - host: myapp.example.com
          paths:
            - path: /
              pathType: Prefix
              portName: http
      tls:
        - secretName: myapp-tls
          hosts:
            - myapp.example.com

    resources:
      limits:
        cpu: 500m
        memory: 512Mi
      requests:
        cpu: 250m
        memory: 256Mi

    livenessProbe:
      httpGet:
        path: /healthz
        port: http
      initialDelaySeconds: 30
      periodSeconds: 10

    readinessProbe:
      httpGet:
        path: /ready
        port: http
      initialDelaySeconds: 5
      periodSeconds: 10
```

### Exemplo 1b: Deployment com Gateway API (Envoy/Envoy Gateway)

Suporte a Gateway API para Envoy, permitindo rules flexíveis: HTTP, HTTPS ou redirect.

```yaml
gatewayApi:
  gatewayClassName: eg
  clusterIssuer: letsencrypt-prod

apps:
  - name: web-app
    enabled: true
    type: deployment
    replicaCount: 2

    image:
      repository: nginx
      tag: "1.21"

    service:
      enabled: true
      ports:
        - name: http
          port: 80
          targetPort: http

    gatewayApi:
      enabled: true
      gateway:
        name: web-app-gateway
        listeners:
          - name: https-main
            hostname: myapp.example.com
            secretName: myapp-tls
      httpRoutes:
        # Redirect HTTP -> HTTPS
        - name: redirect
          listenerName: http-main
          hostnames:
            - myapp.example.com
          rules:
            - type: redirect
              requestRedirect:
                scheme: https
                port: 443
                statusCode: 301
        # Roteamento HTTPS para o service
        - name: main
          listenerName: https-main
          hostnames:
            - myapp.example.com
          rules:
            - type: http
              backendRef:
                port: 80
```

Com `mergeGateways: true` no EnvoyProxy, todos os Gateways são mesclados no mesmo NLB.

Para usar um Gateway existente em vez de criar um novo:

```yaml
gatewayApi:
  enabled: true
  gatewayRef:
    name: shared-gateway
    namespace: networking
  httpRoutes: [...]
```

Para rotas individuais que precisam apontar para um gateway diferente (ex: gateway compartilhado para domínio externo):

```yaml
gatewayApi:
  enabled: true
  gateway:
    name: my-app-gateway
    listeners:
      - name: https-main
        hostname: myapp.internal.com
        secretName: myapp-tls
  httpRoutes:
    # Rota que usa o gateway da própria app
    - name: main
      listenerName: https-main
      hostnames:
        - myapp.internal.com
      rules:
        - type: http
          backendRef:
            port: 80
    # Rota que usa um gateway compartilhado externo
    - name: external
      listenerName: https-external
      gatewayRef:
        name: shared-external-gateway
      hostnames:
        - myapp.external.com
      rules:
        - type: http
          backendRef:
            port: 80
```

### Exemplo 2: Job com ArgoCD Hooks

Jobs do Kubernetes são deletados após a execução (via `ttlSecondsAfterFinished`), o que faz o ArgoCD marcá-los como "Missing". Para resolver, use annotations de hook:

```yaml
apps:
  - name: db-migrate
    enabled: true
    type: job
    annotations:
      argocd.argoproj.io/hook: PreSync
      argocd.argoproj.io/hook-delete-policy: BeforeHookCreation
    image:
      repository: mycompany/api
      tag: v1.0.0
    command: ["dotnet", "MyApp.dll", "--db-setup"]
    backoffLimit: 0
    ttlSecondsAfterFinished: 300
    env:
      - name: ConnectionStrings__Default
        valueFrom:
          secretKeyRef:
            name: my-secret
            key: ConnectionStrings__Default
```

- `PreSync`: o Job roda antes do deploy principal
- `BeforeHookCreation`: o ArgoCD deleta o Job anterior antes de criar um novo no próximo sync

### Exemplo 3: CronJob com External Secrets

```yaml
apps:
  - name: backup-job
    enabled: true
    type: cronjob
    schedule: "0 2 * * *"  # Todo dia às 2h da manhã

    successfulJobsHistoryLimit: 3
    failedJobsHistoryLimit: 1
    concurrencyPolicy: Forbid

    image:
      repository: backup-tool
      tag: latest

    command: ["/bin/sh"]
    args:
      - "-c"
      - |
        echo "Starting backup..."
        # Comandos de backup aqui
        echo "Backup completed"

    secrets:
      external:
        enabled: true
        items:
          - name: aws-credentials
            secretStoreRef:
              name: aws-secret-store
              kind: SecretStore
            refreshInterval: 1h
            data:
              - secretKey: AWS_ACCESS_KEY_ID
                remoteRef:
                  key: prod/backup/aws
                  property: accessKeyId
              - secretKey: AWS_SECRET_ACCESS_KEY
                remoteRef:
                  key: prod/backup/aws
                  property: secretAccessKey

    envFrom:
      - secretRef:
          name: my-apps-backup-job-aws-credentials

    resources:
      limits:
        cpu: 1000m
        memory: 1Gi
      requests:
        cpu: 500m
        memory: 512Mi
```

### Exemplo 4: Deployment com PersistentVolume (S3 CSI)

```yaml
apps:
  - name: api
    enabled: true
    type: deployment
    replicaCount: 2

    image:
      repository: mycompany/api
      tag: v1.0.0

    persistentVolumes:
      enabled: true
      items:
        - name: s3-data-pv
          spec:
            capacity:
              storage: 2Gi
            accessModes:
              - ReadWriteMany
            mountOptions:
              - allow-delete
              - region us-east-2
              - prefix myapp/
            csi:
              driver: s3.csi.aws.com
              volumeHandle: myapp-s3-volume
              volumeAttributes:
                bucketName: my-bucket
                authenticationSource: pod

    persistence:
      enabled: true
      items:
        - name: s3-data
          size: 2Gi
          accessModes:
            - ReadWriteMany
          storageClass: ""
          volumeName: mycompany-api-api-s3-data-pv
          mountPath: /data/s3
```

### Exemplo 5: StatefulSet com Persistence

```yaml
apps:
  - name: database
    enabled: true
    type: statefulset
    replicaCount: 3

    image:
      repository: postgres
      tag: "14-alpine"

    serviceName: database-headless
    podManagementPolicy: OrderedReady

    ports:
      - name: postgresql
        containerPort: 5432
        protocol: TCP

    env:
      - name: POSTGRES_DB
        value: mydb
      - name: PGDATA
        value: /var/lib/postgresql/data/pgdata

    secrets:
      native:
        enabled: true
        items:
          - name: db-creds
            type: Opaque
            stringData:
              POSTGRES_USER: admin
              POSTGRES_PASSWORD: changeme

    envFrom:
      - secretRef:
          name: my-apps-database-db-creds

    livenessProbe:
      exec:
        command:
          - /bin/sh
          - -c
          - pg_isready -U postgres
      initialDelaySeconds: 30
      periodSeconds: 10

    readinessProbe:
      exec:
        command:
          - /bin/sh
          - -c
          - pg_isready -U postgres
      initialDelaySeconds: 5
      periodSeconds: 10

    service:
      enabled: true
      type: ClusterIP
      clusterIP: None  # Headless service
      ports:
        - name: postgresql
          port: 5432
          targetPort: postgresql

    volumeClaimTemplates:
      - metadata:
          name: data
        spec:
          accessModes:
            - ReadWriteOnce
          storageClassName: fast-ssd
          resources:
            requests:
              storage: 50Gi

    volumeMounts:
      - name: data
        mountPath: /var/lib/postgresql/data

    resources:
      limits:
        cpu: 2000m
        memory: 4Gi
      requests:
        cpu: 1000m
        memory: 2Gi
```

### Exemplo 6: Multi-App (Deployment + CronJob)

```yaml
apps:
  # Frontend Application with Autoscaling
  - name: frontend
    enabled: true
    type: deployment
    # NÃO definir replicaCount quando autoscaling está habilitado

    image:
      repository: mycompany/frontend
      tag: v1.2.3

    ports:
      - name: http
        containerPort: 3000

    # Resources são necessários para HPA funcionar
    resources:
      requests:
        cpu: 100m
        memory: 128Mi
      limits:
        cpu: 500m
        memory: 512Mi

    service:
      enabled: true
      ports:
        - name: http
          port: 80
          targetPort: 3000

    ingress:
      enabled: true
      className: nginx
      hosts:
        - host: app.example.com
          paths:
            - path: /
              pathType: Prefix

    # Autoscaling habilitado
    autoscaling:
      enabled: true
      minReplicas: 3
      maxReplicas: 10
      targetCPUUtilizationPercentage: 70
      targetMemoryUtilizationPercentage: 80

  # Background Job
  - name: data-sync
    enabled: true
    type: cronjob
    schedule: "*/30 * * * *"  # A cada 30 minutos

    image:
      repository: mycompany/data-sync
      tag: v1.0.0

    command: ["python"]
    args: ["sync_data.py"]

    secrets:
      external:
        enabled: true
        items:
          - name: api-keys
            secretStoreRef:
              name: aws-secret-store
            data:
              - secretKey: API_KEY
                remoteRef:
                  key: prod/api/keys
                  property: key

    resources:
      limits:
        cpu: 500m
        memory: 512Mi
```

### Exemplo 7: KEDA - Autoscaling Event-Driven

O chart suporta KEDA ScaledObject para autoscaling baseado em eventos (filas SQS, Redis, Kafka, etc.).

#### KEDA com Redis + SQS + CPU

```yaml
serviceAccount:
  create: true
  annotations:
    eks.amazonaws.com/role-arn: "arn:aws:iam::123456789:role/my-role"

apps:
  - name: api
    enabled: true
    type: deployment
    # NÃO definir replicaCount - KEDA gerencia automaticamente

    image:
      repository: mycompany/api
      tag: v1.0.0

    ports:
      - name: http
        containerPort: 8080

    service:
      enabled: true
      ports:
        - name: http
          port: 80
          targetPort: http

    resources:
      limits:
        cpu: 1
        memory: 1Gi
      requests:
        cpu: 100m
        memory: 128Mi

    kedaScaling:
      enabled: true
      minReplicas: 2
      maxReplicas: 16
      pollingInterval: 60
      cooldownPeriod: 300

      # TriggerAuthentication - cria automaticamente o recurso
      triggerAuthentication:
        enabled: true
        podIdentity:
          provider: aws
        secretTargetRef:
          - parameter: host
            name: my-app-secret
            key: REDIS_HOST
          - parameter: port
            name: my-app-secret
            key: REDIS_PORT
          - parameter: password
            name: my-app-secret
            key: REDIS_PASSWORD

      triggers:
        # CPU e Memory
        - type: cpu
          metricType: AverageValue
          metadata:
            value: "800m"
        - type: memory
          metricType: AverageValue
          metadata:
            value: "800Mi"

        # Redis - useAuth injeta o authenticationRef automaticamente
        - type: redis
          useAuth: true
          metadata:
            listName: my-queue
            listLength: "50"
            enableTLS: "false"
            databaseIndex: "0"

        # AWS SQS
        - type: aws-sqs-queue
          useAuth: true
          metadata:
            queueURL: https://sqs.us-east-1.amazonaws.com/123456789/my-queue
            queueLength: "50"
            awsRegion: us-east-1
            identityOwner: operator
```

#### KEDA com Scale to Zero (Workers)

```yaml
apps:
  - name: worker
    enabled: true
    type: deployment
    command: ["python", "worker.py"]

    service:
      enabled: false

    resources:
      limits:
        cpu: 500m
        memory: 512Mi
      requests:
        cpu: 50m
        memory: 128Mi

    kedaScaling:
      enabled: true
      minReplicas: 1
      maxReplicas: 8
      pollingInterval: 30
      cooldownPeriod: 120
      idleReplicaCount: 0  # Scale to zero quando idle

      triggers:
        - type: aws-sqs-queue
          metadata:
            queueURL: https://sqs.us-east-1.amazonaws.com/123456789/worker-queue
            queueLength: "20"
            awsRegion: us-east-1
            identityOwner: operator
```

#### KEDA com Kafka

```yaml
apps:
  - name: consumer
    enabled: true
    type: deployment

    kedaScaling:
      enabled: true
      minReplicas: 1
      maxReplicas: 20
      pollingInterval: 15

      triggerAuthentication:
        enabled: true
        secretTargetRef:
          - parameter: sasl
            name: kafka-credentials
            key: SASL_PASSWORD

      triggers:
        - type: kafka
          useAuth: true
          metadata:
            bootstrapServers: kafka-broker:9092
            consumerGroup: my-consumer-group
            topic: my-topic
            lagThreshold: "100"
```

#### Como funciona o `useAuth`

Quando `triggerAuthentication.enabled: true`, o chart cria um recurso `TriggerAuthentication` automaticamente com o nome `{release}-{chart}-{app-name}-keda-trigger-auth`.

Ao invés de referenciar esse nome manualmente em cada trigger, basta usar `useAuth: true`:

```yaml
# Sem useAuth (manual - funciona, mas verboso):
triggers:
  - type: redis
    metadata:
      listName: my-queue
    authenticationRef:
      name: my-release-deploy-apps-api-keda-trigger-auth

# Com useAuth (automático - recomendado):
triggers:
  - type: redis
    useAuth: true
    metadata:
      listName: my-queue
```

Para usar `ClusterTriggerAuthentication` ou um auth externo, use `authenticationRef` explícito:

```yaml
triggers:
  - type: redis
    metadata:
      listName: my-queue
    authenticationRef:
      name: my-custom-cluster-auth
      kind: ClusterTriggerAuthentication
```

### KEDA vs HPA

| Recurso | HPA (`autoscaling`) | KEDA (`kedaScaling`) |
|---------|---------------------|----------------------|
| CPU/Memory | Sim | Sim |
| AWS SQS | Não | Sim |
| Redis | Não | Sim |
| Kafka | Não | Sim |
| RabbitMQ | Não | Sim |
| Prometheus | Não | Sim |
| Scale to Zero | Não | Sim |
| TriggerAuthentication | N/A | Sim |

Use `autoscaling` para scaling simples baseado em CPU/Memory. Use `kedaScaling` para scaling baseado em eventos ou quando precisar de scale to zero.

## Configuração de Secrets

### External Secrets Operator

Para usar External Secrets, primeiro crie um SecretStore ou ClusterSecretStore:

```yaml
apiVersion: external-secrets.io/v1beta1
kind: SecretStore
metadata:
  name: aws-secret-store
  namespace: default
spec:
  provider:
    aws:
      service: SecretsManager
      region: us-east-1
      auth:
        secretRef:
          accessKeyIDSecretRef:
            name: aws-credentials
            key: access-key-id
          secretAccessKeySecretRef:
            name: aws-credentials
            key: secret-access-key
```

Então configure no values.yaml:

```yaml
apps:
  - name: myapp
    secrets:
      external:
        enabled: true
        items:
          - name: app-secrets
            secretStoreRef:
              name: aws-secret-store
              kind: SecretStore
            data:
              - secretKey: DB_PASSWORD
                remoteRef:
                  key: prod/myapp/database
                  property: password
```

### Native Secrets

Para secrets nativos:

```yaml
apps:
  - name: myapp
    secrets:
      native:
        enabled: true
        items:
          - name: app-secrets
            type: Opaque
            stringData:
              DB_HOST: postgres.example.com
              DB_USER: myuser
              DB_PASSWORD: mypassword
```

### Referência a Secrets Existentes

```yaml
apps:
  - name: myapp
    secrets:
      existing:
        - name: existing-secret-name
    envFrom:
      - secretRef:
          name: existing-secret-name
```

## Labels Customizadas

O chart suporta dois tipos de labels customizadas por aplicação:

### App Labels (aplicadas a TODOS os recursos)

Labels definidas em `apps[].labels` são aplicadas a **todos os recursos** da aplicação (Deployment, Service, Ingress, PVC, ServiceAccount, etc.):

```yaml
apps:
  - name: myapp
    labels:
      team: platform
      cost-center: engineering
      environment: production
```

Essas labels aparecerão em:
- Deployment/StatefulSet/CronJob/Job metadata
- Service metadata
- Ingress metadata
- PVC metadata
- Pod labels (além das podLabels)

### Pod Labels (aplicadas APENAS aos pods)

Labels definidas em `apps[].podLabels` são aplicadas **apenas aos pods**:

```yaml
apps:
  - name: myapp
    podLabels:
      version: v1.2.3
      release: stable
      commit-sha: abc123
```

Essas labels aparecem apenas nas labels dos pods, úteis para:
- Versionamento específico do pod
- Informações de build/release
- Labels que não fazem sentido em Services ou Ingress

### Exemplo Completo

```yaml
apps:
  - name: myapp
    # Labels em todos os recursos
    labels:
      team: platform
      cost-center: engineering

    # Labels apenas nos pods
    podLabels:
      version: v1.2.3
      git-commit: abc123
```

## ServiceAccount

### Uma ServiceAccount por release (recomendado com ArgoCD)

Com `nameFromRelease: true` o nome sai do release (no ArgoCD, o nome da Application), e não do
`fullnameOverride`. Duas releases com o mesmo `fullnameOverride` no mesmo namespace deixam de
renderizar a mesma ServiceAccount (o que deixa as Applications `OutOfSync` disputando o objeto).

```yaml
serviceAccount:
  create: true
  nameFromRelease: true   # SA = <release>
  automount: false        # sem token da API na SA e nos pods
```

### ServiceAccount por componente

Só quando o componente precisa de RBAC ou identidade de nuvem diferente dos demais.

```yaml
serviceAccount:
  create: true
  nameFromRelease: true
  automount: false

apps:
  - name: worker
    serviceAccount:
      create: true          # SA = <release>-worker
      automount: false
      annotations:
        iam.gke.io/gcp-service-account: worker@<projeto>.iam.gserviceaccount.com
```

### Token da API (`automount`)

- `serviceAccount.automount` / `apps[].serviceAccount.automount` são gravados na ServiceAccount
  (inclusive `false`).
- Quando o valor efetivo para o app é `false`, o pod recebe `automountServiceAccountToken: false`.
- `apps[].automountServiceAccountToken` força o valor no pod daquele app (ex.: liga o token só no
  componente que chama a API do Kubernetes).

## RBAC

### RBAC Global (Compartilhado)

```yaml
serviceAccount:
  create: true
  name: my-apps-sa

rbac:
  create: true
  useClusterRole: true
  rules:
    - apiGroups: [""]
      resources: ["pods"]
      verbs: ["get", "list", "watch"]
```

### RBAC Per-App

```yaml
apps:
  - name: myapp
    serviceAccount:
      create: true
      name: myapp-sa
    rbac:
      create: true
      useClusterRole: false
      rules:
        - apiGroups: [""]
          resources: ["configmaps"]
          verbs: ["get", "list"]
```

## Autoscaling

O chart suporta HorizontalPodAutoscaler (HPA) e KEDA ScaledObject para Deployments e StatefulSets.

### Autoscaling Básico (HPA)

```yaml
apps:
  - name: myapp
    type: deployment

    autoscaling:
      enabled: true
      minReplicas: 2
      maxReplicas: 10
      targetCPUUtilizationPercentage: 70
      targetMemoryUtilizationPercentage: 80
```

### Autoscaling com Métricas Customizadas

```yaml
apps:
  - name: myapp
    type: deployment

    autoscaling:
      enabled: true
      minReplicas: 3
      maxReplicas: 50

      # Métricas padrão
      targetCPUUtilizationPercentage: 70

      # Métricas customizadas
      customMetrics:
        - type: Pods
          pods:
            metric:
              name: http_requests_per_second
            target:
              type: AverageValue
              averageValue: "1000"

        - type: External
          external:
            metric:
              name: sqs_queue_length
              selector:
                matchLabels:
                  queue: my-queue
            target:
              type: Value
              value: "100"
```

### Autoscaling com Políticas de Comportamento

Controle fino sobre como o HPA escala para cima e para baixo:

```yaml
apps:
  - name: myapp
    type: deployment

    autoscaling:
      enabled: true
      minReplicas: 2
      maxReplicas: 20
      targetCPUUtilizationPercentage: 70

      behavior:
        # Políticas de scale down (mais conservador)
        scaleDown:
          stabilizationWindowSeconds: 300  # Espera 5 min antes de reduzir
          policies:
            - type: Percent
              value: 50        # Reduz no máximo 50% dos pods
              periodSeconds: 15
            - type: Pods
              value: 2         # Ou no máximo 2 pods
              periodSeconds: 60
          selectPolicy: Min    # Usa a política mais conservadora

        # Políticas de scale up (mais agressivo)
        scaleUp:
          stabilizationWindowSeconds: 0    # Escala imediatamente
          policies:
            - type: Percent
              value: 100       # Dobra o número de pods
              periodSeconds: 15
            - type: Pods
              value: 4         # Ou adiciona 4 pods
              periodSeconds: 15
          selectPolicy: Max    # Usa a política mais agressiva
```

### Importante sobre Autoscaling

1. **Não defina replicaCount**: Quando `autoscaling.enabled` ou `kedaScaling.enabled` é `true`, o chart omite `replicas` do Deployment automaticamente
2. **Métricas necessárias**: Para usar CPU/Memory metrics, é necessário ter Metrics Server instalado no cluster
3. **Apenas para Deployment/StatefulSet**: CronJob e Job não suportam autoscaling
4. **Custom Metrics**: Requer adaptadores de métricas (ex: Prometheus Adapter, Datadog, etc.)
5. **KEDA**: Requer o operador KEDA instalado no cluster

## PodDisruptionBudget (PDB)

O chart pode renderizar um `PodDisruptionBudget` (`policy/v1`) por aplicação, garantindo disponibilidade mínima durante disrupções voluntárias (drain de nós, upgrades, rebalanceamento). Suportado apenas para `deployment` e `statefulset`.

Desabilitado por padrão — apps sem o bloco `pdb` continuam renderizados exatamente como antes.

```yaml
apps:
  - name: api
    enabled: true
    type: deployment
    replicaCount: 3
    pdb:
      enabled: true
      maxUnavailable: 1
```

Usando `minAvailable` (aceita inteiro ou porcentagem):

```yaml
apps:
  - name: api
    enabled: true
    type: deployment
    replicaCount: 4
    pdb:
      enabled: true
      minAvailable: "50%"
```

### Notas sobre PDB

1. **`minAvailable` OU `maxUnavailable`**: são mutuamente exclusivos. Se ambos forem definidos, `minAvailable` tem precedência. Se `pdb.enabled: true` sem nenhum dos dois, o padrão é `maxUnavailable: 1`.
2. **Selector**: o `selector.matchLabels` do PDB reutiliza exatamente o mesmo helper de selector labels do workload, garantindo que o PDB case com os pods corretos.
3. **Apenas Deployment/StatefulSet**: CronJob e Job não geram PDB.
4. **`unhealthyPodEvictionPolicy`** (opcional, k8s >= 1.27): `IfHealthyBudget` (padrão) ou `AlwaysAllow`.

## Valores Configuráveis

| Parâmetro | Descrição | Padrão |
|-----------|-----------|--------|
| `image.repository` | Repository da imagem global | `""` |
| `image.tag` | Tag da imagem global | `""` |
| `image.pullPolicy` | Pull policy global | `IfNotPresent` |
| `imagePullSecrets` | Image pull secrets globais | `[]` |
| `serviceAccount.create` | Criar ServiceAccount global | `true` |
| `serviceAccount.automount` | Montar o token da API (gravado na SA; `false` também no pod) | `true` |
| `serviceAccount.nameFromRelease` | Nomear as SAs pelo release (`<release>`, `<release>-<app>`) | `false` |
| `rbac.create` | Criar RBAC global | `false` |
| `apps` | Array de aplicações | `[]` |

### Parâmetros por Aplicação

| Parâmetro | Descrição | Obrigatório |
|-----------|-----------|-------------|
| `apps[].name` | Nome da aplicação | Sim |
| `apps[].enabled` | Habilitar aplicação | Sim |
| `apps[].type` | Tipo: deployment/statefulset/cronjob/job | Sim |
| `apps[].image.repository` | Repository da imagem | Não |
| `apps[].image.tag` | Tag da imagem | Não |
| `apps[].replicaCount` | Número de réplicas | Não (padrão: 1) |
| `apps[].ports` | Portas do container | Não |
| `apps[].env` | Variáveis de ambiente | Não |
| `apps[].service.enabled` | Criar Service. Auto-habilitado para deployment/statefulset quando `ports` estão definidas. Se não houver `ports` nem `service.ports`, o Service não é criado (evita erro de spec.ports obrigatório) | Não |
| `apps[].ingress.enabled` | Criar Ingress | Não (padrão: false) |
| `apps[].autoscaling.enabled` | Habilitar HPA | Não (padrão: false) |
| `apps[].autoscaling.minReplicas` | Réplicas mínimas (HPA) | Não (padrão: 1) |
| `apps[].autoscaling.maxReplicas` | Réplicas máximas (HPA) | Não (padrão: 10) |
| `apps[].autoscaling.targetCPUUtilizationPercentage` | Target CPU % | Não |
| `apps[].autoscaling.targetMemoryUtilizationPercentage` | Target Memory % | Não |
| `apps[].autoscaling.behavior` | Políticas de scaling | Não |
| `apps[].kedaScaling.enabled` | Habilitar KEDA ScaledObject | Não (padrão: false) |
| `apps[].kedaScaling.minReplicas` | Réplicas mínimas (KEDA) | Não (padrão: 1) |
| `apps[].kedaScaling.maxReplicas` | Réplicas máximas (KEDA) | Não (padrão: 10) |
| `apps[].kedaScaling.pollingInterval` | Intervalo de polling (segundos) | Não |
| `apps[].kedaScaling.cooldownPeriod` | Cooldown antes de scale down (segundos) | Não |
| `apps[].kedaScaling.idleReplicaCount` | Réplicas quando idle (0 para scale to zero) | Não |
| `apps[].kedaScaling.triggerAuthentication.enabled` | Criar TriggerAuthentication | Não (padrão: false) |
| `apps[].kedaScaling.triggerAuthentication.podIdentity` | Pod Identity config (aws, azure, gcp) | Não |
| `apps[].kedaScaling.triggerAuthentication.secretTargetRef` | Refs a secrets para autenticação | Não |
| `apps[].kedaScaling.triggers` | Array de triggers KEDA | Não |
| `apps[].pdb.enabled` | Habilitar PodDisruptionBudget | Não (padrão: false) |
| `apps[].pdb.minAvailable` | Mínimo de pods disponíveis (int ou %). Precede `maxUnavailable` | Não |
| `apps[].pdb.maxUnavailable` | Máximo de pods indisponíveis (int ou %). Padrão `1` se `enabled` sem `minAvailable` | Não |
| `apps[].pdb.unhealthyPodEvictionPolicy` | `IfHealthyBudget` (padrão) ou `AlwaysAllow` (k8s >= 1.27) | Não |
| `apps[].pdb.annotations` | Annotations no PDB | Não |
| `apps[].gatewayApi.httpRoutes[].gatewayRef` | Per-route override para referenciar outro Gateway | Não |
| `apps[].persistentVolumes.enabled` | Habilitar criação de PersistentVolumes | Não (padrão: false) |
| `apps[].persistentVolumes.items` | Array de PVs a criar | Não |
| `apps[].persistentVolumes.items[].name` | Nome do PV (sufixo, prefixado com app fullname) | Sim |
| `apps[].persistentVolumes.items[].spec` | Spec completo do PV (capacity, accessModes, csi, etc.) | Sim |
| `apps[].persistentVolumes.items[].annotations` | Annotations do PV | Não |
| `apps[].persistence.enabled` | Habilitar criação de PVCs | Não (padrão: false) |
| `apps[].persistence.items` | Array de PVCs a criar | Não |
| `apps[].persistence.items[].name` | Nome lógico do volume (compõe o nome do PVC e o volumeMount) | Sim |
| `apps[].persistence.items[].fullnameOverride` | Nome literal do PVC, ignorando o padrão `<appFullname>-<name>`. Útil para adotar um PVC pré-existente pelo nome exato. Ignorado se `existingClaim` estiver definido | Não |
| `apps[].persistence.items[].existingClaim` | Usa um PVC existente (nenhum PVC é renderizado) | Não |
| `apps[].annotations` | Annotations no metadata do recurso (ex: ArgoCD hooks) | Não |
| `apps[].labels` | Labels em todos os recursos | Não |
| `apps[].podLabels` | Labels apenas nos pods | Não |

Para lista completa, veja [values.yaml](values.yaml).

## Desinstalação

```bash
helm uninstall my-apps
```

## Troubleshooting

### Ver recursos criados

```bash
kubectl get all -l app.kubernetes.io/instance=my-apps
```

### Ver logs de uma aplicação

```bash
kubectl logs -l deploy-apps/app-name=myapp --tail=100
```

### Verificar External Secrets

```bash
kubectl get externalsecrets
kubectl describe externalsecret my-apps-myapp-credentials
```

### Verificar KEDA ScaledObjects

```bash
kubectl get scaledobjects
kubectl describe scaledobject my-apps-myapp
kubectl get triggerauthentications
```

### Debug do template

```bash
helm template my-apps ./deploy-apps -f values.yaml --debug
```

## Contribuindo

Contribuições são bem-vindas! Por favor, abra uma issue ou pull request.

## Licença

Apache-2.0

## Maintainers

- Jonathan Schmitt <jonathan.schmitt@cloudscript.com.br>

## Links

- [Cloudscript](https://cloudscript.com.br)
- [External Secrets Operator](https://external-secrets.io)
- [KEDA](https://keda.sh)
