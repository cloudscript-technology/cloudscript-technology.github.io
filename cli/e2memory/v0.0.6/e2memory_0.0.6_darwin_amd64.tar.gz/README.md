# e2memory

Memória vetorizada e **cifrada ponta a ponta** para agentes de IA da CloudScript, organizada em **domínios hierárquicos com chaves derivadas**. Clientes: engenheiros no Claude Code (MCP local) e, depois, o OpsScript por organização. O servidor **nunca** vê texto em claro.

```
Claude Code ──stdio──> e2memory mcp (laptop)        oapi (fase 2)
                        │ embedding: Ollama local   │ chave da org no Vault
                        │ seed → Ed25519 + X25519   │
                        └─ HTTPS + assinatura Ed25519 ┴──> e2memory-api ──> Postgres + pgvector
```

## Modelo: domínios e chaves
- **Domínio** = quem guarda memórias (engenheiro ou org). Tem uma **seed** de 32 bytes; dela derivam (HKDF) uma chave **Ed25519** (autentica requests e assina certificados) e uma **X25519** (envelopes de DEK via age).
- **Subdomínios** em profundidade ilimitada (limites configuráveis). A seed do filho é derivada da do pai com um salt público: o **pai re-deriva qualquer descendente**; o filho **não** sobe nem lateraliza.
- Uma chave lê e escreve **na sua subárvore**. O servidor confere isso por `ltree` (`caller.path @> alvo.path`), mas a barreira dura é a cripto: sem a seed certa não há como abrir o envelope.
- Cada subdomínio nasce com um **certificado assinado pelo pai**; o cliente verifica a cadeia até a raiz **pinada** antes de confiar em qualquer chave/salt vindo do servidor.
- Nomes de subdomínio vão **cifrados** (`label_ct`); o servidor só vê ids opacos e a árvore.
- Compartilhar fora da árvore (`memory_share`) = envelope extra para a chave da outra parte, após confirmar o **fingerprint da raiz** dela.
- **Rotação** de um subdomínio (feita pelo pai): nova versão de chave, memórias re-envelopadas, chave antiga recusada. Por enquanto só para domínios **folha**; rotação de raiz = árvore nova.
- **Seed raiz perdida = árvore inteira perdida.** Backup obrigatório de `~/.config/e2memory/identity.json`. Com `e2memory init --passphrase` a seed fica cifrada em repouso (Argon2id + XChaCha20; `E2MEMORY_PASSPHRASE` ou prompt).

## Instalar o CLI (colegas)
```bash
curl -fsSL https://charts.cloudscript.com.br/cli/e2memory/install.sh | sh     # detecta OS/arch, verifica checksum (e cosign, se instalado), instala em ~/.local/bin
e2memory setup --url https://e2memory.foundation.management.kubescript.io --handoff 'E2M-HANDOFF-...'   # identidade recebida do líder do time
```
Binários por versão em `https://charts.cloudscript.com.br/cli/e2memory/<tag>/` (mesma tag da imagem/API), `latest` e `index.json`; publicados pela esteira `ci-production` no repo `cloudscript-technology.github.io`. Versão fixa: `E2MEMORY_VERSION=v0.1.0 curl … | sh`.

## Rodar local (fase 1)
```bash
make up                       # postgres+pgvector, migrate (Job), api :8080, ollama :11434 (+ pull do modelo)
make install                  # binário em ~/.local/bin/e2memory

# titular de uma raiz (engenheiro)
export E2MEMORY_API_URL=http://localhost:8080
e2memory init --url $E2MEMORY_API_URL          # gera a seed; imprime o bundle E2M-ROOT-... para o admin
# admin registra a raiz (só a chave pública viaja)
E2MEMORY_ADMIN_TOKEN=... e2memory admin create-root --name jonathan --bundle E2M-ROOT-...
e2memory whoami

e2memory save --summary "Atlantis x WAF" "regra managed do Cloudflare bloqueia o webhook POST"
e2memory search por que o plan não roda no PR
e2memory domain create acme                    # imprime o handoff E2M-HANDOFF-... (seed do filho) UMA vez
e2memory save --domain acme --summary "..." "..." # o pai escreve dentro do filho

# titular do subdomínio (agente/oapi/colega): instala a seed recebida
E2MEMORY_IDENTITY_FILE=~/.config/e2memory/acme.json e2memory init --handoff E2M-HANDOFF-...
e2memory domain rotate acme                    # pai: nova chave + re-envelope; novo handoff
```

Claude Code (`.mcp.json`):
```json
{ "e2memory": { "command": "e2memory", "args": ["mcp"],
  "env": { "E2MEMORY_API_URL": "https://e2memory.foundation.management.kubescript.io" } } }
```
Variáveis do cliente: `E2MEMORY_API_URL`, `E2MEMORY_IDENTITY_FILE` (default `~/.config/e2memory/identity.json`) e as de embedding (seção abaixo).

Variáveis do servidor: `DATABASE_URL` (ou `PGHOST`/`PGUSER`/`PGPASSWORD`/`PGDATABASE`/`PGSSLMODE`), `LISTEN` (`:8080`), `E2MEMORY_ADMIN_TOKEN` (só para registrar raízes), `EMBED_MODEL`, `EMBED_DIM` (768), `E2M_MAX_DEPTH` (5), `E2M_MAX_CHILDREN` (50), `E2M_MAX_MEMORIES` (20000), `E2M_MAX_BYTES_MB` (512), `AUTO_MIGRATE` (default false; em cluster as migrations rodam no Job `e2memory-api migrate`, Job na sync-wave 0 do ArgoCD).

## Sidecar (`e2memory agent`): qualquer linguagem
Em vez de uma lib por linguagem, o binário roda ao lado do sistema consumidor (daemon no laptop ou **container sidecar no mesmo pod**) e expõe uma API **em texto claro só em localhost/unix socket**. Ele guarda a seed, calcula embeddings pelo serviço configurado, cifra, deriva chaves e assina. O texto em claro nunca sai do host/pod.

```bash
e2memory agent --listen 127.0.0.1:8787 --token <segredo-local>     # ou --listen unix:/run/e2memory.sock
curl -s localhost:8787/v1/search -H 'Authorization: Bearer <segredo-local>' -d '{"query":"por que o plan não roda no PR","k":5}'
curl -s localhost:8787/v1/save   -H 'Authorization: Bearer <segredo-local>' -d '{"domain":"acme","summary":"...","content":"..."}'
```
Rotas: `GET /v1/me`, `POST /v1/search {query, domain?, recursive?, k?, min_score?}`, `POST /v1/get {ids}`, `POST /v1/save {domain?, summary, content, update_id?, force?}` (409 + `similar` quando há duplicata), `DELETE /v1/memories/{id}`, `POST /v1/share`, `POST /v1/revoke`, `GET /v1/domains`, `POST /v1/domains {name, parent?, limits?}`.

## Embedding: escolha o serviço
O embedding roda **fora da API** (no cliente/sidecar), sempre no mesmo modelo que o servidor pina (`EMBED_MODEL`/`EMBED_DIM`). O serviço é configurável:

| var | valores |
|---|---|
| `E2MEMORY_EMBEDDER` | `ollama` (default) ou `openai` = qualquer `/v1/embeddings` compatível (Hugging Face **TEI**, vLLM, LiteLLM, OpenAI, Voyage) |
| `E2MEMORY_EMBED_URL` | base URL do serviço (`http://localhost:11434`, `http://tei:80`, …) |
| `E2MEMORY_EMBED_MODEL` | id do modelo como o servidor pina (`nomic-embed-text:v1.5`) |
| `E2MEMORY_EMBED_API_KEY` | bearer para o serviço, se houver |
| `E2MEMORY_EMBED_PREFIX_QUERY` / `_DOC` | prefixos de tarefa (default por família: nomic `search_query:`/`search_document:`, e5 `query:`/`passage:`) |

Exemplo TEI como sidecar de embedding no mesmo pod: `ghcr.io/huggingface/text-embeddings-inference:cpu-latest --model-id nomic-ai/nomic-embed-text-v1.5` e `E2MEMORY_EMBEDDER=openai E2MEMORY_EMBED_URL=http://localhost:80`.

## Autenticação
Requests assinadas com a Ed25519 do domínio (`X-E2M-Key`, `X-E2M-Ts`, `X-E2M-Nonce`, `X-E2M-Sig`), janela de ±5 min e nonce único (anti-replay). Não há tokens de usuário; o bearer `E2MEMORY_ADMIN_TOKEN` serve só para `POST /v1/admin/roots`.

## Tools MCP
| tool | faz |
|---|---|
| `memory_search(query, domain?, recursive?, k?)` | busca semântica na sua subárvore (+ compartilhadas); `id \| score \| domínio \| resumo` |
| `memory_get(ids)` | conteúdo completo |
| `memory_save(domain?, summary, content, update_id?, force?)` | salva cifrado num domínio que você controla; devolve similares > 0.92 em vez de duplicar |
| `memory_forget(id)` | apaga |
| `memory_share(id, grantee_domain, root_fingerprint?)` | envelope extra para outro domínio (fingerprint da raiz dele confirmado fora da ferramenta) |
| `memory_revoke(id, grantee_domain)` | remove o grant (forward-only) |
| `domain_list()` | sua árvore com rótulos decifrados |
| `domain_create(name, parent?, max_depth?)` | cria subdomínio e devolve o handoff (segredo, entregar fora de banda) |

## Arquitetura do código

Dois binários: **`e2memory`** (client: CLI, MCP, agent — nunca linka API, banco ou migrations) e **`e2memory-api`** (`serve`, `migrate`; só na imagem Docker). Tipos de wire compartilhados em `internal/wire`.

```
cmd/cli/            client → internal/cli
cmd/api/                 server (binário e2memory-api) → internal/apicmd (serve, migrate)
internal/wire/           tipos JSON da API (compartilhados por api e client)
internal/cli/            um arquivo por grupo de comandos (cobra); zero regra de negócio
internal/config/         configuração tipada carregada uma vez (único lugar que lê env); String() redige segredos
internal/apperr/         erro único: Code (E2M_*), Message, HTTPStatus, Retryable, Cause — atravessa todas as camadas
internal/httpx/          middlewares (request-id, recover, access log), WriteJSON/WriteError únicos, ParseErrorBody
internal/protocol/       constantes do fio (headers, versões canônicas, limites)
internal/telemetry/      OpenTelemetry (OTLP via OTEL_*), tracer/meter, slog com trace_id
internal/domain/         entidades (Domain, KeyVersion, Memory, Row) sem SQL/HTTP
internal/service/        regras: authz por subárvore, certificados, limites, rotação, memórias, grants
internal/store/postgres/ SQL puro (pgx + otelpgx); Repo/Tx; advisory lock nos jobs
internal/api/            handlers finos, autenticação por assinatura, probes, rate limit de 401
internal/agent/          sidecar (API local em texto claro) sobre o client
internal/mcp/            tools MCP sobre o client
internal/client/         operações; transport/ (RoundTripper assinante + retry idempotente + otelhttp); trust/ (pins, cadeia, cache de derivação)
internal/embed/          provedores (Ollama, OpenAI-compatível) + Chain (fallback no MESMO modelo, circuit breaker)
internal/crypto/         primitivas puras e versionadas
api/                     OpenAPI da API (openapi.yaml) e do agent (openapi-agent.yaml)
database/                migrations (padrão oapi, golang-migrate)
```

**Erros:** toda camada devolve `*apperr.Error`; a API serializa `{"error":{"code","message","request_id"}}`; o client reconstrói o mesmo erro a partir do código; agent e MCP só repassam. Erros internos nunca vazam a causa (vai para o log com `request_id`).

**Resiliência:** o client re-tenta só operações idempotentes (GET/PUT/DELETE, `POST /v1/memories` com id do cliente, search/get/keys) em erros `Retryable` (5xx, 429, drain), assinando de novo a cada tentativa; embedding tem cadeia de endpoints do **mesmo modelo** com circuit breaker (`E2MEMORY_EMBED_URL=a,b`).

**Telemetria:** `otelhttp` nos dois lados com `traceparent` propagado; spans `service.*`, `embed`, `trust.chain`, `client.Search/Save`; SQL via `otelpgx`; logs JSON com `trace_id`. Nunca texto, query, seed ou envelope em atributo.

**Ciclo de vida (Kubernetes, N pods):** servidor stateless (nonces no Postgres; job de limpeza com `pg_try_advisory_xact_lock`). `GET /healthz` = vivo (com `version`/`commit`/`built_at`); `GET /readyz` = ping no banco e `503` durante o drain. Em SIGTERM: readiness → 503, espera `PRESTOP_DELAY` (5 s, endpoint sai do Service), `Shutdown` drena até `SHUTDOWN_TIMEOUT` (25 s), flush do OTel, fecha o pool. `terminationGracePeriodSeconds` ≥ soma dos dois.

## Testes
`make test` roda `internal/crypto` (derivação, certificados, assinatura) e a integração (`internal/client/client_test.go`) contra o Postgres do compose: filho não lê pai/irmão, pai lê e escreve na subárvore, rótulos cifrados, rotação com re-envelope, share entre árvores com fingerprint, limites (`max_depth`, `max_children`, `max_memories`), dedup, replay e skew rejeitados.

## Deploy (produção, cluster management)
- Esteira (`.github/workflows/ci-production.yml`, `workflow_dispatch`): `kubescript/create-release` → `kubescript/build-push-ghcr` (imagem do **servidor**, `ghcr.io/cloudscript-technology/e2memory:v<semver>`) → GoReleaser (binário do **client**) → **trivy bloqueante**. **Não faz deploy.**
- Deploy é GitOps no `iac-kubernetes`: chart fino sobre `deploy-apps` em `clients/002-cloudscript-technology/sistemas/production/us-east-1/main/e2memory/e2memory`; subir versão = PR alterando `deploy-apps.image.tag` para a tag da release.
- Migrations: Job `e2memory-migrate` na **sync-wave 0** com `Replace=true` e a API na wave 1: o ArgoCD só aplica o Deployment quando o Job conclui (migration antes do novo ReplicaSet). Hook PreSync não serve: roda antes de SA/ExternalSecrets existirem.
- Banco: CNPG `e2memory-db` (Postgres 17 + pgvector) e backup dumpscript, no mesmo diretório do iac-kubernetes; exposto pelo ingress-nginx **privado** do management (`https://e2memory.foundation.management.kubescript.io`, acesso via VPN).
- Secrets (AWS Secrets Manager, só referenciados): `foundation/management/e2memory/db` (`username`, `password`) e `foundation/management/e2memory/api` (`admin_token`).
